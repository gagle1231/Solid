// Import from "@inrupt/solid-client-authn-browser"
import {
  login,
   handleIncomingRedirect,
   getDefaultSession,
   fetch,
   Session,
   events,
 } from "@inrupt/solid-client-authn-browser";
 import { createDpopHeader, generateDpopKeyPair, buildAuthenticatedFetch } from '@inrupt/solid-client-authn-core';
 // Import from "@inrupt/solid-client"
 import {
   addUrl,
   addStringNoLocale,
   createSolidDataset,
   createThing,
   getPodUrlAll,
   getSolidDataset,
   getThingAll,
   getThing,
   getStringNoLocale,
   removeThing,
   saveSolidDatasetAt,
   setThing,
   setStringNoLocale,
   universalAccess, //권한 부여
 } from "@inrupt/solid-client";
 
 import { SCHEMA_INRUPT, RDF, AS, VCARD } from "@inrupt/vocab-common-rdf";
 
 const selectorIdP = document.querySelector("#select-idp");
 const selectorPod = document.querySelector("#select-pod");
 const buttonLogin = document.querySelector("#btnLogin");
 const buttonRead = document.querySelector("#btnRead");
 const buttonCreate = document.querySelector("#btnCreate");
 const buttonGT = document.querySelector("#btnGenerateToken");
 const fileCreate = document.querySelector("#btnSend");
 const labelCreateStatus = document.querySelector("#labelCreateStatus");
 const buttonViewor = document.querySelector("#btnViewor");  // 권한 부여를 위해 추가 
 const selectorPod3 = document.querySelector("#select-pod3");  // 권한 부여를 위해 추가
 const writeForm = document.getElementById("writeForm");
 const readForm = document.getElementById("readForm");
 const fileForm = document.getElementById("fileForm");
 
 const NOT_ENTERED_WEBID =
 "...not logged in yet - but enter any WebID to read from its profile...";

 //버튼 비활성화 상태로 (조건 미충족 시 비활성화)
 buttonRead.setAttribute("disabled", "disabled");
 buttonLogin.setAttribute("disabled", "disabled");
 buttonCreate.setAttribute("disabled", "disabled");
 fileCreate.setAttribute("disabled", "disabled");
 buttonViewor.setAttribute("disabled", "disabled"); // 권한 부여를 위해 추가
 const session = getDefaultSession();
 if (session.info.isLoggedIn) {
   // Update the page with the status.
   document.getElementById("myWebID").value = session.info.webId;
   document.getElementById("webID").value = session.info.webId;

   // Enable Read button to read Pod URL
   buttonRead.removeAttribute("disabled");
 }



 // 1a. Start Login Process. Call login() function.
function loginToSelectedIdP() {
   const SELECTED_IDP = document.getElementById("select-idp").value;
   return login({
     oidcIssuer: SELECTED_IDP,
     redirectUrl: "http://localhost:1234/",
     clientName: "Getting started app",
     
   });
}

//solid community 로그인 시 token 발급 
async function generateToken(){
  //1. id와 secret 발급
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const response = await fetch('http://localhost:3000/idp/credentials/', {
     method: 'POST',
     headers: { 'content-type': 'application/json' },
     // The email/password fields are those of your account.
     // The name field will be used when generating the ID of your token.
     body: JSON.stringify({ email: email, password: password, name: 'my-token' }),
   });
  const { id, secret } = await response.json();
  console.log(id);
  console.log(secret);
  document.getElementById("idToken").textContent = "id: "+id;
  document.getElementById("secret").textContent = "secret: " + secret;
  
  //2. 발급받은 id와 secret으로 access token 발급
  const dpopKey = await generateDpopKeyPair();
  const authString = `${encodeURIComponent(id)}:${encodeURIComponent(secret)}`;
  const tokenUrl = 'http://localhost:3000/.oidc/token';
  const responseToken = await fetch(tokenUrl, {
  method: 'POST',
  headers: {
    // The header needs to be in base64 encoding.
    authorization: `Basic ${Buffer.from(authString).toString('base64')}`,
    'content-type': 'application/x-www-form-urlencoded',
    dpop: await createDpopHeader(tokenUrl, 'POST', dpopKey),
  },
  body: 'grant_type=client_credentials&scope=webid',
});
const { access_token: accessToken } = await responseToken.json();
console.log(accessToken);

// 3. token으로 request 보내기 test
// const authFetch = await buildAuthenticatedFetch(fetch, accessToken, { dpopKey });
// const response2 = await authFetch('http://localhost:3000/gaeun');
// const {data} = await response2.json();
// console.log(data)
}

 // 1b. Login Redirect. Call handleIncomingRedirect() function.
 // When redirected after login, finish the process by retrieving session information.
 async function handleRedirectAfterLogin() {
   await handleIncomingRedirect();
 
   const session = getDefaultSession();
   if (session.info.isLoggedIn) {
     // Update the page with the status.
     console.log(session.info);
     document.getElementById("myWebID").value = session.info.webId;
     document.getElementById("webID").value = session.info.webId;
 
     // Enable Read button to read Pod URL
     buttonRead.removeAttribute("disabled");
   }
 }
 
 // The example has the login redirect back to the index.html.
 // This calls the function to process login information.
 // If the function is called when not part of the login redirect, the function is a no-op.
 handleRedirectAfterLogin();
 
 // 2. Get Pod(s) associated with the WebID
 async function getMyPods() {
   const webID = document.getElementById("myWebID").value;
   const mypods = await getPodUrlAll(webID, { fetch: fetch });
   mypods.forEach((mypod) => {
     let podOption = document.createElement("option");
     podOption.textContent = mypod;
     podOption.value = mypod;
     selectorPod.appendChild(podOption);
     // 가져온 모든 팟을 드롭다운 하위 메뉴로 넣는 과정
   });

   mypods.forEach((mypod) => {
     let podOption = document.createElement("option");
     podOption.textContent = mypod;
     podOption.value = mypod;
     selectorPod3.appendChild(podOption);
     // 가져온 모든 팟을 드롭다운 하위 메뉴로 넣는 과정
   });
 }

 // Make new file
 async function writeFile() {
   const title = document.getElementById("file_name").value;

   document.getElementById(
     "fileWriteStatus"
   ).textContent = `File [${title}] successfully sended!`;
 }
 
 // 3. Create the Reading List
 async function createList() {
   labelCreateStatus.textContent = "";
   const SELECTED_POD = document.getElementById("select-pod").value;
   const FILE_TITLE = document.getElementById("file_name").value;
 
   // For simplicity and brevity, this tutorial hardcodes the  SolidDataset URL.
   // In practice, you should add in your profile a link to this resource
   // such that applications can follow to find your list.
   
   const readingListUrl = `${SELECTED_POD}getting-started/readingList/${FILE_TITLE}`;

   // 내 팟 주소 아래의 getting-started 디렉토리 하위에 readingList/myList 추가 (readingList의 경로)
 
   let titles = document.getElementById("titles").value.split("\n");

   // Fetch or create a new reading list.
   let myReadingList;
 
   try {
     // Attempt to retrieve the reading list in case it already exists.
     // 목록이 존재하는 경우 getSolidDataset 함수 이용해 모든 목록 가져옴
     myReadingList = await getSolidDataset(readingListUrl, { fetch: fetch });
     // Clear the list to override the whole list
     // getThingAll 함수 이용해 모든 목록들의 요소 삭제
     let items = getThingAll(myReadingList);
     items.forEach((item) => {
       myReadingList = removeThing(myReadingList, item);
     });
   } catch (error) {
     if (typeof error.statusCode === "number" && error.statusCode === 404) {
       // if not found, create a new SolidDataset (i.e., the reading list)
       myReadingList = createSolidDataset();
     } else {
       console.error(error.message);
     }
   }
 
   // Add titles to the Dataset
   let i = 0;
   titles.forEach((title) => {
     if (title.trim() !== "") {
       let item = createThing({ name: "title" + i });
       item = addUrl(item, RDF.type, AS.Article);
       item = addStringNoLocale(item, SCHEMA_INRUPT.name, title);
       myReadingList = setThing(myReadingList, item);
       i++;
     }
   });
 
   try {
     // Save the SolidDataset
     // saveSolidDatasetAt 함수 이용해 readingListUrl에 myReadingList를 저장
     let savedReadingList = await saveSolidDatasetAt(
       readingListUrl,
       myReadingList,
       { fetch: fetch }
     );
 
     // create 버튼 누르고 마지막 박스에 saved 출력되게끔
     //labelCreateStatus.textContent = readingListUrl + " Saved";
     
     // Refetch the Reading List
     savedReadingList = await getSolidDataset(readingListUrl, { fetch: fetch });
 
     let items = getThingAll(savedReadingList);
 
     let listcontent = "";
     for (let i = 0; i < items.length; i++) {
       let item = getStringNoLocale(items[i], SCHEMA_INRUPT.name);
       if (item !== null) {
         listcontent += item + "\n";
       }
     }
 
     document.getElementById("savedtitles").value = listcontent;
   } catch (error) {
     console.log(error);
     labelCreateStatus.textContent = "Error" + error;
     labelCreateStatus.setAttribute("role", "alert");
   }
 }

 // location 경로 출력
 async function copyLocation() {
   const SELECTED_POD = document.getElementById("select-pod").value;
   const title = document.getElementById("file_name").value;

   document.getElementById(
     "labelLink"
   ).textContent = `${SELECTED_POD}getting-started/readingList/${title}`;
   // 지금은 getting-started/readingList/ 라고 경로를 지정해주었고, 디렉토리명 입력받으면 이 부분 수정
 }

 // 4. Grant Permission
 selectorPod3.addEventListener("change", pod3SelectionHandler);
 function pod3SelectionHandler() {
   if (selectorPod3.value === "") {
     buttonViewor.setAttribute("disabled", "disabled");
   } else {
     buttonViewor.removeAttribute("disabled");
   }
 }

 // Grant Edit Permission 버튼 클릭 시 호출
 async function editPermission() {
   const SELECTED_POD = document.getElementById("select-pod3").value;
   const path = document.getElementById("input_permission_path").value;
   const grantFileUrl = `${SELECTED_POD}` + path;  // 권한 부여하고 싶은 파일 경로
   const inputWebID = document.getElementById("grant_webID").value;  // 권한 부여하고 싶은 WebID

   console.log("path : " + grantFileUrl);
   console.log("webid : " + inputWebID);

   // 액세스 권한 부여 검색을 위해 추가
   // 자원 소유자가 Access Request 요청을 허용 및 거부할 때
   // 승인/거부된 Access Grant의 ID(VC로 직렬화)가 요청하는 앱으로 쿼리 매개변수로 전송
   // 요청하는 앱은 아래 메소드로 Access Grant를 가져올 수 있음.
   const session = getDefaultSession();
   const webID = session.info.webId;

   // Change Agent Access
   // Resource에 대한 Agent의 액세스 권한 설정
   universalAccess.setAgentAccess(
     grantFileUrl,         // Resource
     inputWebID,     // Agent
     { read: true, write: false, },          // Access object
     { fetch: fetch }                         // fetch function from authenticated session
   ).then((newAccess) => {
     logAccessInfo(inputWebID, newAccess, grantFileUrl)
   });
   
   console.log("View 권한 부여 성공");
   
   function logAccessInfo(agent, agentAccess, resource) {
     console.log(`For resource::: ${resource}`);
     if (agentAccess === null) {
       console.log(`Could not load ${agent}'s access details.`);
     } else {
       console.log(`${agent}'s Access:: ${JSON.stringify(agentAccess)}`);
     }
   }
 }

 // 권한 location 복사용
 async function copyLocation2() {
   const SELECTED_POD = document.getElementById("select-pod3").value;
   const url = document.getElementById("input_permission_path").value;

   document.getElementById(
     "labelLink2"
   ).textContent = `${SELECTED_POD}${url}`;
 }

 // 5. Write to profile
 async function writeProfile() {
   const name = document.getElementById("input_name").value;
   const session = getDefaultSession();

   if (!session.info.isLoggedIn) {
     // You must be authenticated to write.
     document.getElementById(
       "labelWriteStatus"
     ).textContent = `...you can't write [${name}] until you first login!`;
     document.getElementById("labelWriteStatus").setAttribute("role", "alert");
     // 해당 요소를 사용자에게 알리는 중요한 정보로 인식 가능
     return;
   }
   const webID = session.info.webId;
   // The WebID can contain a hash fragment (e.g. `#me`) to refer to profile data
   // in the profile dataset. If we strip the hash, we get the URL of the full
   // dataset.
   const mypods = await getPodUrlAll(webID, { fetch: fetch });
   const profileDocumentUrl = new URL(mypods + "profile");
   profileDocumentUrl.hash = "";
 
   // To write to a profile, you must be authenticated. That is the role of the fetch
   // parameter in the following call.
   let myProfileDataset = await getSolidDataset(profileDocumentUrl.href, {
     fetch: session.fetch
   });
 
   // The profile data is a "Thing" in the profile dataset.
   let profile = getThing(myProfileDataset, webID);
 
   // Using the name provided in text field, update the name in your profile.
   // VCARD.fn object is a convenience object that includes the identifier string "http://www.w3.org/2006/vcard/ns#fn".
   // As an alternative, you can pass in the "http://www.w3.org/2006/vcard/ns#fn" string instead of VCARD.fn.
   profile = setStringNoLocale(profile, VCARD.fn, name);
 
   // Write back the profile to the dataset.
   myProfileDataset = setThing(myProfileDataset, profile);
 
   // Write back the dataset to your Pod.
   await saveSolidDatasetAt(profileDocumentUrl.href, myProfileDataset, {
     fetch: session.fetch
   });
 
   // Update the page with the retrieved values.
   document.getElementById(
     "labelWriteStatus"
   ).textContent = `Wrote [${name}] as name successfully!`;
   document.getElementById("labelWriteStatus").setAttribute("role", "alert");
   document.getElementById(
     "labelFN"
   ).textContent = `...click the 'Read Profile' button to to see what the name might be now...?!`;
 }

 // 6. Read profile
 async function readProfile() {
   // const webID = document.getElementById("webID").value;
   const session = getDefaultSession();
   const webID = session.info.webId;

   if (webID === NOT_ENTERED_WEBID) {
     document.getElementById(
       "labelFN"
     ).textContent = `Login first, or enter a WebID (any WebID!) to read from its profile`;
     return false;
   }

   try {
     new URL(webID);
   } catch (_) {
     document.getElementById(
       "labelFN"
     ).textContent = `Provided WebID [${webID}] is not a valid URL - please try again`;
     return false;
   }

   // const SELECTED_IDP = document.getElementById("select-idp").value;
   // 에서 뽑아오는 값에 따라 조건문 처리?
   const mypods = await getPodUrlAll(webID, { fetch: fetch });
   const profileDocumentUrl = new URL(mypods + "profile");
   // inrupt.net 선택 시 277행만 단일 실행
   // const profileDocumentUrl = new URL(webID);
   profileDocumentUrl.hash = "";

   // Profile is public data; i.e., you do not need to be logged in to read the data.
   // For illustrative purposes, shows both an authenticated and non-authenticated reads.

   let myDataset;
   try {
     if (session.info.isLoggedIn) {
       myDataset = await getSolidDataset(profileDocumentUrl.href, { fetch: session.fetch });
     } else {
       myDataset = await getSolidDataset(profileDocumentUrl.href);
     }
   } catch (error) {
     document.getElementById(
       "labelFN"
     ).textContent = `Entered value [${webID}] does not appear to be a WebID. Error: [${error}]`;
     return false;
   }

   const profile = getThing(myDataset, webID);

   // Get the formatted name (fn) using the property identifier "http://www.w3.org/2006/vcard/ns#fn".
   // VCARD.fn object is a convenience object that includes the identifier string "http://www.w3.org/2006/vcard/ns#fn".
   // As an alternative, you can pass in the "http://www.w3.org/2006/vcard/ns#fn" string instead of VCARD.fn.

   const formattedName = getStringNoLocale(profile, VCARD.fn);

   // Update the page with the retrieved values.
   document.getElementById("labelFN").textContent = `[${formattedName}]`;
 }
 
 buttonLogin.onclick = function () {
   loginToSelectedIdP();
 };
 
 buttonRead.onclick = function () {
   getMyPods();
 };

 buttonCreate.onclick = function () {
   createList();
   copyLocation();
 };

 fileForm.addEventListener("submit", (event) => {
   event.preventDefault();
   writeFile();
 });

 buttonViewor.onclick = function() {
   editPermission();
   copyLocation2();
 };

 writeForm.addEventListener("submit", (event) => {
   event.preventDefault();
   writeProfile();
 });

 readForm.addEventListener("submit", (event) => {
   event.preventDefault();
   readProfile();
 });
 
 idTokenForm.addEventListener("submit", (event) => {
  event.preventDefault();
  generateToken();
 })
 // 이벤트가 발생하면 idpSelectionHandler 함수 호출
 // 미로그인 시 버튼 비활성화, 로그인 시 활성화
 selectorIdP.addEventListener("change", idpSelectionHandler);
 function idpSelectionHandler() {
   if (selectorIdP.value === "") {
     buttonLogin.setAttribute("disabled", "disabled");
   } else {
     buttonLogin.removeAttribute("disabled");
   }
 }
 
 // 마찬가지로 팟이 선택되지 않았을 경우 버튼 비활성화, 선택될 경우 활성화
 selectorPod.addEventListener("change", podSelectionHandler);
 function podSelectionHandler() {
   if (selectorPod.value === "") {
     buttonCreate.setAttribute("disabled", "disabled");
     fileCreate.setAttribute("disabled", "disabled");
   } else {
     buttonCreate.removeAttribute("disabled");
     fileCreate.removeAttribute("disabled");

   }
 }